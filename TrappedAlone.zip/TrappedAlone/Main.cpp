#include <iostream>
#include <string>
#include "Screen.h"
#include "Sound.h"

bool SDL() {
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
	{
		std::cout << "SDL_mixer could not load! SDL_mixer error: " << Mix_GetError() << endl;
		return false;
	}
	return true;
}







void test1()
{

	Screen screen(800, 600, "TrappedAlone");
	


	SDL();
	Mix_Music* pBackgroundTrack = NULL;
	Mix_Chunk* pKeyPressA = NULL;
	Mix_Chunk* pKeyPressS = NULL;
	Mix_Chunk* pKeyPressD = NULL;
	Mix_Chunk* pKeyPressW = NULL;

	pBackgroundTrack = backgroundMusic("Music.wav");
	pKeyPressA = soundBite("Ice.wav");
	pKeyPressS = soundBite("TM1.wav");
	pKeyPressD = soundBite("TM2.wav");
	pKeyPressW = soundBite("Slap.wav");
	Mix_PlayMusic(pBackgroundTrack, -1);

	while (!screen.Exited())
	{


		glClearColor(0.0f, 0.15f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		SDL_Event pressed;

		while (SDL_PollEvent(&pressed))
		{
			switch (pressed.type)
			{
			case SDL_KEYDOWN:
				switch (pressed.key.keysym.sym)
				{
				case SDLK_w:
					std::cout << "W pressed" << std::endl;
					Mix_PlayChannel(0, pKeyPressW, 0);
					break;
				case SDLK_s:
					std::cout << "S pressed" << std::endl;
					Mix_PlayChannel(0, pKeyPressS, 0);
					break;
				case SDLK_a:
					std::cout << "A pressed" << std::endl;
					Mix_PlayChannel(0, pKeyPressA, 0);
					break;
				case SDLK_d:
					std::cout << "D pressed" << std::endl;
					Mix_PlayChannel(0, pKeyPressD, 0);
					break;
				}
				break;
			}
		}

		screen.Update();


	}

	Mix_HaltMusic();
	Mix_FreeMusic(pBackgroundTrack);
	Mix_FreeChunk(pKeyPressA);
	Mix_FreeChunk(pKeyPressS);
	Mix_FreeChunk(pKeyPressW);
	Mix_FreeChunk(pKeyPressD);
	pBackgroundTrack = NULL;




}









int main(int argc, char *argv[])
{
	test1();

	return 0;
}