#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <iostream>
#include <string>

using namespace std;

Mix_Music* backgroundMusic(string path);
Mix_Chunk* soundBite(string path);

